from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('cms', '0002_initial'),
    ]

    operations = [
        migrations.RenameField(
            model_name='introduction',
            old_name='introduction',
            new_name='detail',
        ),
    ]
