from django.contrib import admin
from .models import Introduction
# Register your models here.

class IntroductionAdmin(admin.ModelAdmin):
	list_display = ('name', 'email', 'school', 'majors')


admin.site.register(Introduction)
